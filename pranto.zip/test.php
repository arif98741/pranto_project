<?php

echo "<pre>";
print_r($_SERVER['PHP_SELF']);
echo "<pre>";
