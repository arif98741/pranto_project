

	<script src="node_modules/jquery/dist/jquery.min.js"></script>
	<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
	<script src="asset/js/main.js"></script>
</body>
</html>